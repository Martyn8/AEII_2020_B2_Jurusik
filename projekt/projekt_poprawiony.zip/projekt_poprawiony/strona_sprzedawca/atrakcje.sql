SELECT id_cennika FROM cennik WHERE typ='Atrakcja' AND rodzaj='rodzaj_atrakcji';

INSERT INTO atrakcja values(NULL,'$typ_atrakcji','$rodzaj_atrakcji','$zegarek','$id_cennika','$lista_nazwa');

DELETE FROM atrakcja WHERE zegarek_id_zegarka='$id_zegarka';



SELECT 